from person import Person

class Client(Person):
    pass