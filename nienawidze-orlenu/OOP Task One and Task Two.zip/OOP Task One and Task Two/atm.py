class ATM:
    def __init__(self, location, bank):
        self.location = location
        self.bank = bank

    def check_balance(self, account):
        return account.balance

    def deposit(self, account, amount):
        account.deposit(amount)
        return account.balance

    def withdraw(self, account, amount):
        if account.withdraw(amount):
            return account.balance
        else:
            return "Brak środków na koncie"