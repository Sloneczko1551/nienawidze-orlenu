class Transaction:
    def __init__(self, account, amount, transaction_type, datetime):
        self.account = account
        self.amount = amount
        self.transaction_type = transaction_type
        self.timestamp = datetime.now()

    def __str__(self):
        return f"{self.transaction_type} transakcja {self.amount} na konto {self.account.owner.name} dnia {self.timestamp}"