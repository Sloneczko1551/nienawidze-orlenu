class TransactionHistory:
    def __init__(self):
        self.transactions = []

    def add_transaction(self, transaction):
        self.transactions.append(transaction)
    
    def get_history(self, account):
        return [t for t in self.transactions if t.account == account]