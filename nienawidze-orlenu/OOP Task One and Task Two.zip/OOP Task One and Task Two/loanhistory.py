class LoanHistory:
    def __init__(self):
        self.loans = []

    def add_loan(self, loan):
        self.loans.append(loan)

    def get_loans(self, client):
        return [loan for loan in self.loans if loan.client == client]