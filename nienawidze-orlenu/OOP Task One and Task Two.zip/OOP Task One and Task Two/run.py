from Bank import Bank
from account import Account
from client import Client

def main():
    bank = Bank("CMAZ")
    client = Client("Jan Burnejko")
    account = Account(client, 1000)
    bank.add_account(account)

    if account.withdraw(500):
        print("Wypłata zakończona sukcesem")
    else:
        print("Brak środków na koncie")

    account.deposit(200)
    print("Ilość środków:", account.balance)

if __name__ == "__main__":
    main()