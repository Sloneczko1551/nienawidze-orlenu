class BankBranch:
    def __init__(self, name, address):
        self.name = name
        self.address = address
        self.clients = []

    def add_client(self, client):
        self.clients.append(client)

    def get_clients(self):
        return self.clients