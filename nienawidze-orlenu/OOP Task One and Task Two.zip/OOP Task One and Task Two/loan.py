class Loan:
    def __init__(self, loan_amount, interest_rate, loan_period, client):
        self.loan_amount = loan_amount
        self.interest_rate = interest_rate
        self.loan_period = loan_period
        self.client = client

    def calculate_interest(self):
        return self.loan_amount * (self.interest_rate / 100) * (self.loan_period / 12)